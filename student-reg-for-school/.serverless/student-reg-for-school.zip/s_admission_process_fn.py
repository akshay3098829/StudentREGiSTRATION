import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='akshaymohan',
    application_name='studentreg',
    app_uid='yGr6Jg7xQg9LLWqWzJ',
    org_uid='1fef85f8-6ced-4f45-8bf5-658a4136efd3',
    deployment_uid='c2cf2272-3a7d-49d8-9ba3-ee9361cadff7',
    service_name='student-reg-for-school',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='7.2.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'admission-process-lambda', 'timeout': 10}
try:
    user_handler = serverless_sdk.get_user_handler('src/lambdas/stepfunction_lambda_handler.lambda_handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
