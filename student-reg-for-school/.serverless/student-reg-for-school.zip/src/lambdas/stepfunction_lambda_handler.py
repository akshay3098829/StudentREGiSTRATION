def lambda_handler(event, context):
    print("stepfunction111111111111111111111",event)
    return